package com.weixiao.myapplicationlab3;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Display extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        View txtName = findViewById(R.id.txtName);


    }

    public void onClickListener(View view){
        setContentView(R.layout.activity_main);
    }
}