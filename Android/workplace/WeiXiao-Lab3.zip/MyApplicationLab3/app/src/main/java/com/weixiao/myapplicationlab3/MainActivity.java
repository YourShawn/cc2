package com.weixiao.myapplicationlab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickListener(View view){
        EditText editName = findViewById(R.id.editName);
        EditText editEmail = findViewById(R.id.editEmail);
        CheckBox checkBox = findViewById(R.id.checkBox);

        Account account = new Account();
        account.setName(editName.getText().toString());
        account.setEmail(editEmail.getText().toString());
        account.setSubscribed(checkBox.isClickable());

        Intent intent = new Intent(this, Display.class);
        intent.putExtra("editName",account.getName());
        intent.putExtra("editEmail",account.getEmail());
        intent.putExtra("checkBox",account.isSubscribed());
        startActivity(intent);
    }
}