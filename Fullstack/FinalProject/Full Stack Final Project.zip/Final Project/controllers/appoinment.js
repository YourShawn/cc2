module.exports=(req, res) => {
    req.session.bookMessage="";
    res.render("appointment",
      {message: req.session.appointmentMessage}
    );
  }