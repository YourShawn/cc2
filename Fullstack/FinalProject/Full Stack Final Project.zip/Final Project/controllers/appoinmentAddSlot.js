//model
const Appointment = require("../models/Appointment");

module.exports = async (req, res) => {
    const date=new Date(req.body.dateAddSlot);   
    
    const dataAppointment={
        date: date,
        time: req.body.hourAppointment,
        available: true 
    };
    await Appointment.create(dataAppointment, (error, Appointment) => {    
        if(error){
            console.log(error);
            req.session.appointmentMessage = ['Error creating the record in the database']; 
            res.redirect("/appointment");          
        }
        else{
            req.session.appointmentMessage = ['Time slot added succesfully ']; 
            res.redirect("/appointment");  
        }                 
      });
};