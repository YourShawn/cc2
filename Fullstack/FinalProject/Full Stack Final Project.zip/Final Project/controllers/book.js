module.exports=(req, res) => {
    req.session.appointmentMessage="";
    res.render("book",
      {message: req.session.bookMessage}
    );
  }