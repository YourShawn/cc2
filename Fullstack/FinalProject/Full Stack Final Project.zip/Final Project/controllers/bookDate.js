//model
const Appointment = require("../models/Appointment");
const User = require("../models/User");

module.exports = async (req, res) => {
    //console.log("BODY",req.body.dateAddSlot+"T00:00:00.000Z");

    if(req.body._id){
        const id=req.body._id;
        //console.log("hour slot",id); 
        const appointmentModel={
            available: false
          };
        //   Update appointment 
          Appointment.findByIdAndUpdate(id, appointmentModel, (error,Appointment)=>{
            if(error){
                console.log(error);
            }            
            //   Update User
            const userId=req.session.userId;
            const userModel={
                appointmentId: id,
                testType: req.body.typeTest
            };
            User.findByIdAndUpdate(userId, userModel, (error,User)=>{
                if(error){
                    console.log(error);
                }
                res.redirect("/");   
            });            
          });       
          
    }
    else{
        const infoAppointment = await Appointment.find({ date: req.body.dateAddSlot }); 
        //console.log(" SLOTS ",infoAppointment);   
        
    
        if(infoAppointment.length>0){
            res.render("book",{
                    dateAddSlot:req.body.dateAddSlot,
                    message:["Choose your time"],
                    appointments: infoAppointment
                });
        }
        else{
            res.render("book",{message:["There is not slot time created"]});
        }   
    }
     
};