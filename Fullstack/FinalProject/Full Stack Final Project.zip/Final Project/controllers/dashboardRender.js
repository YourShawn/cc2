module.exports=function (req, res) {
    delete req.session['appointmentMessage'];//Delete error message property. Not display in appointment page
    delete req.session['bookMessage'];//Delete error message property. Not display in book page
    delete req.session['validationErrors'];//Delete error message property. Not display in login page
    res.render("dashboard");
}