const User = require('../models/User');

module.exports= async (req, res) => {
    User.find({ tookTest: false, usertype:'Driver' }).populate("appointmentId").exec((error, user) => {
        if(error){
            res.render("examiner",
                     {message: "Error happened fetching the info driver user"});
        }
        else{
            //console.log(user);
            res.render("examiner",
                     {message: "",
                    infoUser:user});
        }
      });
  }