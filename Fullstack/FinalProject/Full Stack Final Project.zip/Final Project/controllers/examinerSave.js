//model
const User = require("../models/User");


module.exports = async (req, res) => {
    
        
        const boolean=(req.body.passTest==="true");
        //console.log("hour slot",id); 
        const userModel={
            comments:req.body.comments,
            passOrFail:boolean,
            tookTest:true
          };
          //console.log(req.body.idUser,boolean,userModel);
            // Update user 
          User.findByIdAndUpdate(req.body.idUser, userModel, (error,user)=>{
            if(error){
                console.log(error);
            } 
            res.render("dashboard");         
          });         
};