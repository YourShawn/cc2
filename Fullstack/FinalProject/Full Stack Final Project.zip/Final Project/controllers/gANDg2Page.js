const User = require("../models/User");

module.exports=(req, res) => {
    User.findById(req.session.userId, function (err, info) {
      if (err){
          console.log(err);
      }
      else{
        const infoUser=[];
        infoUser[0]=info;                
        if(info.usertype=="Driver"){
            if(info.firstname==""){
                res.render("g2_test");
              }
              else{
                 res.render("g_test",{ infoUser });
            }
        }
        else{
            res.render("dashboard");
        }
                 
      }
    });
};