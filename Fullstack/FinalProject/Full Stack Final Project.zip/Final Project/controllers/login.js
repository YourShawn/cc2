//model
const User = require("../models/User");
const bcrypt=require('bcrypt');

module.exports = (req, res) =>{
    const { username, password } = req.body;
    User.findOne({username:username}, (error,user) => {
        if (user){
                bcrypt.compare(password, user.password, (error, same) =>{
                    if(error){
                        console.log(error);
                    }
                    else{
                        if(same){ 
                            req.session.userId = user._id;
                            req.session.userType = user.usertype;
                            res.redirect('/');
                        } 
                        else{  
                            //req.session.destroy();   
                            req.session.validationErrors = ['Authentication Error: please verify username and password.'];                            
                            res.redirect('/login');
                        }                       
                    } 
                });                  
        } 
        else{
            req.session.validationErrors = ['Authentication Error: please verify username and password.']; 
            res.redirect('/login');
        }
        });
};
    