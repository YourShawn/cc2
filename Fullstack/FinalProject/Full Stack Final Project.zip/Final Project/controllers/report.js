const User = require('../models/User');

module.exports= async (req, res) => {

   

    //console.log(reportPass);
    //console.log(reportFail);

    if(userType=='Driver'){
        const userReport=await User.find({ _id:req.session.userId,tookTest: true, usertype:'Driver' }).populate("appointmentId");
        console.log(userReport);
        console.log(req.session.userId);
        if(userReport.length>0){
            if(userReport[0].tookTest==false){
                res.render("report",{
            infoUserPass: [],
            infoUserFail: [],
            message: "User has not been evaluated."
          });
            }
            else{
                let reportPass;
                let reportFail;
                if(userReport[0].passOrFail==true){
                    reportPass=userReport;
                    reportFail=[];
                }
                else{
                    reportPass=[];
                    reportFail=userReport;
                }
                res.render("report",{
                    infoUserPass: reportPass,
                    infoUserFail: reportFail,
                    message: ""
                });
            }
        }
        else{
            res.render("report",{
                infoUserPass: [],
                infoUserFail: [],
                message: ["User not exists"]
            });
        }        
    }
    else{
        const reportPass=await User.find({ passOrFail:true,tookTest: true, usertype:'Driver' }).populate("appointmentId");
        const reportFail=await User.find({ passOrFail:false,tookTest: true, usertype:'Driver' }).populate("appointmentId");
        res.render("report",{
            infoUserPass: reportPass,
            infoUserFail: reportFail,
            message: ""
          });
    }
    
  };

