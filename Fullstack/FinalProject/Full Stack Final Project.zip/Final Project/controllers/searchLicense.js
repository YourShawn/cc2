//model
const User = require("../models/User");

module.exports = async (req, res) => {
    const infoUser = await User.find({ license: req.body.license });    
    res.render("g_test", { infoUser });
};