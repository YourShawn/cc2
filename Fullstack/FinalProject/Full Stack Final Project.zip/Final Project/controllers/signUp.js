//model
const User = require("../models/User");

module.exports= async(req,res)=>{ 
    await User.create(req.body, (error, User) => {    
      if(error){
        const validationErrors = Object.keys(error.errors).map(key =>
          error.errors[key].message);
        req.session.validationErrors = validationErrors;
        return res.redirect("/login");
      }
      res.redirect("/");            
    });
};