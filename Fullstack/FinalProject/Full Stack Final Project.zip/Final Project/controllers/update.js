//model
const User = require("../models/User");

module.exports = async (req,res)=>{
    const infoUser = await User.find({ license: req.body.license });
    const id=infoUser[0]._id.toString();    
    const userModel={
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      license: req.body.license,
      age: req.body.age,
      car_details:{
        make: req.body.make,
        model: req.body.model,
        year: req.body.year,
        plateno: req.body.plateno
      }
    };
    User.findByIdAndUpdate(id, userModel, (error,User)=>{
      res.redirect("/");   
    });
};