const express = require("express");
const path = require("path");
const app = new express();

const expressSession = require('express-session');
app.use(expressSession({
  secret: 'keyboard cat'
  }));

const ejs = require("ejs");
app.set("view engine", "ejs");

app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded());

global.loggedIn = null;
global.userType=null;
app.use("*", (req, res, next) => {
  userType=req.session.userType;
  loggedIn = req.session.userId;      
  next()
});

//Midlewares
const authMiddleware=require('./middlewares/authMiddleware');
const authMiddlewareExaminer=require('./middlewares/authMiddlewareExaminer');
const redirectIfAuthMiddleware=require('./middlewares/redirectIfAuthenticatedMiddleware');
const appoinmentMiddleware=require('./middlewares/appointmentMiddleware');
const addAppointmentMiddleware=require('./middlewares/addAppointmentMiddleware');
const reportMiddleware=require('./middlewares/reportMiddleware');

//home nad dashboard
const dashboardController=require('./controllers/dashboardRender');
app.get("/", dashboardController);
app.get("/dashboard", dashboardController);

//login

const loginRenderController=require('./controllers/loginRender');
app.get("/login", redirectIfAuthMiddleware,loginRenderController);

// app.listen(4000, () => {
//   console.log("App listening on port 4000");
// });
let port = process.env.PORT;
if (port == null || port == "") {
  port = 4000;
}
app.listen(port, ()=>{
console.log('App listening...')
});

//connection to mongodb
const mongoose = require("mongoose");
mongoose.connect(
  "mongodb+srv://ricardoparra:Tabata0815@cluster0.qnc9ybh.mongodb.net/assignment",
  { useNewUrlParser: true }
);

const addUserController=require('./controllers/addUser');
app.post("/g2/add", authMiddleware, addUserController);

//search license
const searchLicenseController=require('./controllers/searchLicense');
app.post("/g", authMiddleware, searchLicenseController);

//update info user
const updateController=require('./controllers/update');
app.post("/g/update", authMiddleware, updateController);

//create user
const signUpController=require('./controllers/signUp');
app.post("/login/signup", redirectIfAuthMiddleware, signUpController);

//lougout user
const logOutController=require('./controllers/logout');
app.get('/auth/logout',logOutController);

//login user
const loginInController=require('./controllers/login');
app.post('/auth/login', redirectIfAuthMiddleware, loginInController);

//g2
const gANDg2PageController=require('./controllers/gANDg2Page');
app.get("/g2", authMiddleware, gANDg2PageController);
// g
app.get("/g", authMiddleware, gANDg2PageController);

//appoinment page
const appoinmentController=require('./controllers/appoinment');
app.get("/appointment",appoinmentMiddleware,appoinmentController);

//add slot time
const appoinmentAddSlotController=require('./controllers/appoinmentAddSlot');
app.post('/appointment/addSlot',addAppointmentMiddleware,appoinmentAddSlotController);

//book page
const bookController=require('./controllers/book');
app.get("/book",authMiddleware,bookController);

//book page when choose date
const bookDateController=require('./controllers/bookDate');
app.post("/book",authMiddleware,bookDateController);


//examiner page
const examinerController=require('./controllers/examiner');
app.get("/examiner",authMiddlewareExaminer,examinerController);

//examiner filter
const examinerFilterController=require('./controllers/examinerFilter');
app.post("/examinerfilter",authMiddlewareExaminer,examinerFilterController);

//examiner pick
const examinerPickController=require('./controllers/examinerPick');
app.post("/examinerpick",authMiddlewareExaminer,examinerPickController);

//examiner save
const examinerSaveController=require('./controllers/examinerSave');
app.post("/examinersave",authMiddlewareExaminer,examinerSaveController);

//report
const reportController=require('./controllers/report');
app.get("/report",reportMiddleware,reportController);

//Page not found
app.use((req,res)=>res.render("notfound"));









