//model
const Appointment = require("../models/Appointment");

module.exports = async (req, res, next) => {
    
    const date=new Date(req.body.dateAddSlot+"T00:00:00.000Z");             
    const infoAppointment = await Appointment.find({ date: date });  
    let duplicate=false;  
  
   if(infoAppointment.length>0){
        
        for(let i=0;i<infoAppointment.length;i++){
            if(parseInt(infoAppointment[i].time)==parseInt(req.body.hourAppointment)){//To validate duplicate
                duplicate=true;
            }
        }            
    }
    // console.log(duplicate);
    if(duplicate){
        req.session.appointmentMessage= ["Time slot already exists"];
        res.redirect("/appointment");
    }
    else{
        next();
    }
        
};

// module.exports = async (req, res, next) => {
    
//     const date=new Date(req.body.dateAddSlot);   
//     date.setHours(date.getHours()+parseInt(req.body.hourAppointment));
//     console.log(date);  
//     let dateNow=new Date();
//     dateNow.setHours(dateNow.getHours()-4);
    
    
//     if(dateNow<date){
//         const infoAppointment = await Appointment.find({ date: date });    
    
//         if(infoAppointment.length>0){
//             req.session.appointmentMessage= ["Time slot already exists"];
//             res.redirect("/appointment");
//         }
//         else{
//             next();
//         }
//     }
//     else{
//         req.session.appointmentMessage= ["Time slot must be greater than "+dateNow];
//         res.redirect("/appointment");
//     }
        
// };