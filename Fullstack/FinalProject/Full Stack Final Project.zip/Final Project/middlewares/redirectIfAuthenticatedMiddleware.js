module.exports = (req, res, next) =>{
    if(req.session.userId){
        console.log("Redirect user logged in");
        return res.redirect('/'); // if user logged in, redirect to home page       
    }
    next();
};