const User = require('../models/User');

module.exports=(req, res, next) => {
    User.findById(req.session.userId, (error, user ) =>{
        if(error || !user || user.usertype=="Examiner") {//user is Driver or Admin
            return res.redirect('/');
        }            
        next();
        })
};