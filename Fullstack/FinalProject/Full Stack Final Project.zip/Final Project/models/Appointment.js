const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AppoinmentSchema = new Schema({
    date: {
        type: Date,
        default:new Date()
        },
    time: {
            type:String,
            default:""
        },
    available: {
            type:Boolean,default:false
        } 
});


const Appointment = mongoose.model("Appointment", AppoinmentSchema);
module.exports = Appointment;
