const mongoose = require("mongoose");
const Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
const bcrypt=require('bcrypt');

const UserSchema = new Schema({
  firstname: {type:String,default:""},
  lastname: {type:String,default:""},
  license: {type:String,default:""},
  age: {type:Number,default:0},
  username:{type:String, required:true, unique:true, default:""},
  password:{type:String, required:true,default:""},
  usertype: {type:String, default:'Driver'},
  car_details:{
    make: {type:String,default:""},
    model: {type:String,default:""},
    year: {type:Number,default:0},
    plateno: {type:String,default:""},
  },
  appointmentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Appointment",
  },
  testType:{type:String,default:""},
  comments:{type:String,default:""},
  passOrFail:{type:Boolean,default:false},
  tookTest:{type:Boolean,default:false}
});

UserSchema.pre('save',function(next){
  const user=this;

  if(user.password!=""){
    bcrypt.hash(user.password,10,(error,hash)=>{
      user.password=hash;
      next();
    });
  }  
});

UserSchema.plugin(uniqueValidator);

const User = mongoose.model("User", UserSchema);
module.exports = User;
