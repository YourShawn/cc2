"use strict";

$(document).ready(() => {

    $("#buttonRegister").click(evt=>{
        
        if($("#username").val()=="" || $("#password").val()=="" || $("#con-password").val()==""){
            $("#signupAlert").text("Username/Password must not be empty");
            evt.preventDefault();
        }
        else if($("#password").val()!=$("#con-password").val()){
            $("#signupAlert").text("Password must be the same");
            evt.preventDefault();
        }
    });

});