"use strict";

const displayScores = (scores, scoresString) => {
    let score_sum = scores.reduce((accumulator, currentValue) =>{
        return accumulator + currentValue;
    });
    let average_score = score_sum/scores.length;

    $('#scores').val(scoresString.join("\n"));
	$('#avr_score').text(average_score);
};
    
$(document).ready( () => {
    // var stringArray = [];
    // var scoreArray = [];
    $("#add_button").click( () => {
        // let first_name = $("#first_name").val();
        // let last_name = $("#last_name").val();
        // let score = parseInt($("#score").val());
        
        // let string_element = `${last_name}, ${first_name}: ${score}`
        // stringArray.push(string_element);
        // scoreArray.push(score);

        // displayScores(scoreArray, stringArray);

        // // get the add form ready for next entry
        // $("#first_name").val( "" );
        // $("#last_name").val( "" );
        // $("#score").val( "" );
        // $("#first_name").focus();
    }); // end click()
    
    $("#clear_button").click( () => {
        // stringArray= [];
        // scoreArray = [];
        // remove the score data from the web page
        $("#avr_score").val( "" );
        $("#scores").val( "" );

        $("#first_name").focus();
    }); // end click()
       
    $("#sort_button").click( () => {
        let sortedArray = stringArray.sort();
        $('#scores').val(sortedArray.join("\n"));
    }); // end click()
    
    $("#first_name").focus();
}); // end ready()