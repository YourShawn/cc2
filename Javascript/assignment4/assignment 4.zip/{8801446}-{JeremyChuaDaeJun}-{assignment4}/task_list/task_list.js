"use strict";

$(document).ready( () => {
    const tasks = [];

    $("#add_task").click( () => {   
        const textbox = $("#task");
        const task = textbox.val();
        if (task === "") {
            alert("Please enter a task.");
            textbox.focus();
        } else {
            // add task to array
            // let splitTask = task.split(',');
            // let task_number = 1;
            // for (let loop = 0; loop < splitTask.length; loop++){
            //     let taskAssignment = `${task_number}: ${splitTask[loop].trim()}`;
            //     tasks.push(taskAssignment);
            //     task_number++;
            // }
            
            // clear task text box and re-display tasks
            textbox.val("");

            // tasks.forEach(element => {
                
            // });

            $("#task_list").val(tasks.join("\n"));
            textbox.focus();
        }
    });
    
    $("#clear_tasks").click( () => {
        tasks.length = 0;
        $("#task_list").val("");
        $("#task").focus();
    }); 
    
    $("#task").focus();
});