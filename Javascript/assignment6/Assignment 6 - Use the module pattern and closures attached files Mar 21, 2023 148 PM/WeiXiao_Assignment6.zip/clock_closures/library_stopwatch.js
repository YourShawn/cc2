"use strict";

const createStopwatch = (minuteSpan, secondSpan, msSpan) => {
    // private state
    var stopwatchTimer = null;
    

    
    // public methods
    return {
        start(){
            if (timerCurrent == null) {
                timerCurrent = createClock();
                stopwatchTimer = timerCurrent.start();
                console.log("start parameter:", stopwatchTimer, timerCurrent);
            }
           console.log("start:", stopwatchTimer);
        },

        stop(){
            console.log("Stop:", stopwatchTimer);
            clearInterval(stopwatchTimer);
            stopwatchTimer = null;
            timerCurrent = null;
        },

        reset(){
            // console.log("Reset:", stopwatchTimer);
            // this.stop();
            
            //  elapsed = { minutes: 0, seconds: 0, milliseconds: 0 };
             $("#s_minutes").text("00");
             $("#s_seconds").text("00");
             $("#s_ms").text("000");
             console.log("Reset End:", stopwatchTimer);
        },
    }
};