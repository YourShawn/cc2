function displayMenu() {

    const nav = $("#linkMenu").css("display");  
    if (nav != "none") {
        $("#linkMenu").css("display","none");
    } else {
        $("#linkMenu").css("display","block");
    }
}